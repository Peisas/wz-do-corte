// Cole aqui o código completo do site da WZ do Corte
// Hero, Flyers, Serviços, WhatsApp, total, etc.
